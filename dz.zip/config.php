<?php
$linktoken= 'http://vanthuanit.org/token.txt'; // nên để trong file txt nhé
$uid= '100013433205152'; // ID user vip
?>