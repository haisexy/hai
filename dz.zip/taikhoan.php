<?php
$dataLog  =  array(
'email' => '', // Tài khoản Facebook
'pass' => '', // Mật khẩu Facebook
'apps' =>'41158896424',# ID App Token
);
?>